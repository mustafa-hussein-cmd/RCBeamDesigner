# RC Beam Designer — Android App
### تحويل كود Python (Flet) → تطبيق أندرويد أصلي (Kotlin)

---

## 📱 مميزات التطبيق

| الميزة | الوصف |
|--------|-------|
| **نفس المنطق الحسابي تماماً** | جميع معادلات ACI 318 منقولة بدقة من Python |
| **3 شاشات** | Input / Results / Diagram |
| **رسم تلقائي للكمرة** | مقطع عرضي + مسقط طولي بدون مكتبات خارجية |
| **تحقق كامل** | As,min، ductility، φVc، spacing limits |
| **ETABS Integration** | يقبل Vu (kN) أو Av/s (mm²/m) مباشرة |

---

## 🗂 هيكل الملفات

```
RCBeamDesigner/
├── app/src/main/
│   ├── java/com/rcbeam/designer/
│   │   ├── MainActivity.kt          # Activity الرئيسية + Bottom Navigation
│   │   ├── BeamDesignEngine.kt      # ⭐ كل الحسابات (مرجع Python بالكامل)
│   │   ├── BeamViewModel.kt         # مشاركة البيانات بين الـ Fragments
│   │   ├── InputFragment.kt         # شاشة الإدخال
│   │   ├── ResultsFragment.kt       # تقرير ACI 318
│   │   └── DiagramFragment.kt       # رسم الكمرة (Canvas مخصص)
│   ├── res/
│   │   ├── layout/                  # activity_main + 3 fragments
│   │   ├── menu/bottom_nav_menu.xml
│   │   ├── values/ (colors, themes, strings)
│   │   └── drawable/spinner_bg.xml
│   └── AndroidManifest.xml
├── build.gradle
└── settings.gradle
```

---

## 🚀 خطوات التشغيل في Android Studio

### 1️⃣ افتح المشروع
- افتح **Android Studio** → `File > Open`
- اختر مجلد `RCBeamDesigner`

### 2️⃣ انتظر المزامنة
- سيبدأ Gradle في تحميل المكتبات تلقائياً
- انتظر حتى يختفي شريط التقدم في الأسفل

### 3️⃣ اختر الجهاز
- **Emulator**: `Device Manager > Create Virtual Device > Pixel 7 > API 34`
- **هاتف حقيقي**: فعّل `Developer Options > USB Debugging`

### 4️⃣ اضغط ▶ Run
- سيُبنى APK وينصّب على الجهاز تلقائياً

---

## 🔧 متطلبات البيئة

| المتطلب | الإصدار |
|---------|---------|
| Android Studio | Hedgehog (2023.1.1) أو أحدث |
| Kotlin | 1.9.22 |
| compileSdk | 34 (Android 14) |
| minSdk | 26 (Android 8.0) |
| Gradle | 8.2.0 |

---

## 🔄 مقارنة Python → Kotlin

| Python (Flet) | Kotlin (Android) |
|---------------|-----------------|
| `ft.Page` | `MainActivity` + Fragments |
| `ft.Dropdown` | `Spinner` |
| `ft.TextField` | `TextInputEditText` |
| `MatplotlibChart` | `BeamDrawingView` (Canvas مخصص) |
| `check_aci_limits()` | `BeamDesignEngine.design()` |
| `calculate_bars()` | `BeamDesignEngine.calculateBars()` |
| `numpy` | حسابات Kotlin الأصلية |
| `matplotlib` | Android Canvas API |

---

## 📝 ملاحظات هامة

- جميع المعادلات محققة: **fc = 28 MPa، fy = 420 MPa، cover = 60 mm**
- يدعم إطارات عادية (**Ordinary**) وزلزالية (**Intermediate** - ACI 18.4)
- حساب أوزان الكانات تلقائي (kg/m)
- أطوال التثبيت بالخطاف (Ldh) تُحسب فقط عند وجود عمود خارجي
