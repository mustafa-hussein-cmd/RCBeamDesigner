package com.rcbeam.designer

import kotlin.math.*

// ─── Constants ───────────────────────────────────────────────────────────────
object BeamConstants {
    val BAR_DIAMETERS = mapOf(10 to 78.5, 12 to 113.1, 16 to 201.1, 20 to 314.2, 25 to 490.9, 32 to 804.2)
    const val F_C = 28.0   // MPa  (concrete compressive strength)
    const val F_Y = 420.0  // MPa  (steel yield strength)
    const val PHI_SHEAR = 0.75
    const val DEFAULT_COVER = 40.0 // mm to stirrup face
    const val EFFECTIVE_COVER = 60.0 // mm to bar centre
}

// ─── Data classes ────────────────────────────────────────────────────────────
data class BeamInput(
    val b: Double,             // width  mm
    val h: Double,             // height mm
    val asTop: Double,         // required top steel  mm²
    val asBot: Double,         // required bot steel  mm²
    val topDia: Int,           // top bar diameter    mm
    val botDia: Int,           // bot bar diameter    mm
    val stirrupDia: Int,       // stirrup diameter    mm
    val shearValue: Double,    // Vu kN  OR  Av/s mm²/m
    val inputMethod: ShearMethod,
    val frameType: FrameType,
    val leftSupport: SupportType,
    val rightSupport: SupportType
)

data class BeamResult(
    val nTop: Int,
    val nBot: Int,
    val asMinReq: Double,
    val phiVc: Double,         // kN
    val avSReq: Double,        // mm²/m
    val avSProvided: Double,   // mm²/m
    val sCrit: Int,            // mm
    val sMid: Int,             // mm
    val zoneLenMm: Int,        // critical zone length mm (0 if ordinary)
    val ldHTop: Double,        // hook development length mm
    val ldHBot: Double,
    val hookExtTop: Double,
    val hookExtBot: Double,
    val stirrupHookExt: Double,
    val stirrupWeightPerMeter: Double,
    val notes: List<String>,
    val warnings: List<String>,
    val input: BeamInput
)

enum class FrameType(val label: String) {
    ORDINARY("Ordinary Moment Frame"),
    INTERMEDIATE("Intermediate Moment Frame");
    companion object { fun fromLabel(l: String) = values().first { it.label == l } }
}

enum class SupportType(val label: String) {
    EXTERNAL("External Column"),
    INTERNAL("Internal Column");
    companion object { fun fromLabel(l: String) = values().first { it.label == l } }
}

enum class ShearMethod(val label: String) {
    VU("Design Shear Force Vu (kN)"),
    AVS("Rebar Area Av/s (mm²/m)");
    companion object { fun fromLabel(l: String) = values().first { it.label == l } }
}

// ─── Design Engine ────────────────────────────────────────────────────────────
object BeamDesignEngine {

    private fun barArea(dia: Int) = BeamConstants.BAR_DIAMETERS[dia] ?: 78.5

    fun calculateBars(asReq: Double, barDia: Int): Int {
        if (asReq <= 0) return 2
        return max(2, ceil(asReq / barArea(barDia)).toInt())
    }

    fun design(inp: BeamInput): BeamResult {
        val notes = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        val d = inp.h - BeamConstants.EFFECTIVE_COVER
        val fc = BeamConstants.F_C
        val fy = BeamConstants.F_Y

        // ── Development lengths ─────────────────────────────────────────────
        val ldHTop = max(150.0, (0.24 * fy * inp.topDia) / sqrt(fc))
        val ldHBot = max(150.0, (0.24 * fy * inp.botDia) / sqrt(fc))
        val hookExtTop = 12.0 * inp.topDia
        val hookExtBot = 12.0 * inp.botDia
        val stirrupHookExt = max(75.0, 6.0 * inp.stirrupDia)

        // ── Minimum steel ───────────────────────────────────────────────────
        val asMin = max(
            (0.25 * sqrt(fc) / fy) * inp.b * d,
            (1.4 / fy) * inp.b * d
        )
        notes += "As,min (longitudinal): ${asMin.fmt1} mm²"

        if (inp.asTop in 0.001..asMin) warnings += "⚠️ Top As (${inp.asTop.fmt1}) < code minimum (${asMin.fmt1} mm²)"
        if (inp.asBot in 0.001..asMin) warnings += "⚠️ Bottom As (${inp.asBot.fmt1}) < code minimum (${asMin.fmt1} mm²)"

        // ── Seismic / frame provisions ──────────────────────────────────────
        if (inp.frameType == FrameType.INTERMEDIATE) {
            notes += "🔹 Seismic provisions — Intermediate Frames (ACI 18.4)"
            if (inp.asBot < inp.asTop / 3.0)
                warnings += "❌ Ductility Failure: Bottom As < 1/3 of Top As!"
        } else {
            notes += "🔹 Ordinary Frame provisions applied"
        }

        // ── Shear capacity ──────────────────────────────────────────────────
        val avTotal = 2.0 * barArea(inp.stirrupDia)   // 2-leg stirrup
        val vC = 0.17 * sqrt(fc) * inp.b * d
        val phiVc = BeamConstants.PHI_SHEAR * vC / 1000.0  // kN
        notes += "Concrete Shear Capacity (φVc): ${phiVc.fmt1} kN"

        // ── Shear demand → spacing ──────────────────────────────────────────
        val avSReq: Double
        val sDemand: Double

        if (inp.inputMethod == ShearMethod.VU) {
            val vu = inp.shearValue * 1000.0   // N
            notes += "ETABS Demand Vu: ${inp.shearValue.fmt1} kN"
            val excess = (vu / BeamConstants.PHI_SHEAR) - vC
            avSReq = if (vu <= phiVc * 1000 / 2) 0.0 else max(0.0, excess) / (fy * d) * 1000.0
            sDemand = if (vu <= phiVc * 1000 / 2) d / 2
            else if (excess > 0) (avTotal / avSReq) * 1000.0 else d / 2
        } else {
            avSReq = inp.shearValue
            notes += "ETABS Demand Av/s: ${avSReq.fmt2} mm²/m"
            sDemand = if (avSReq <= 0) d / 2 else (avTotal / avSReq) * 1000.0
        }

        // ── Spacing limits ──────────────────────────────────────────────────
        val sMaxCrit = if (inp.frameType == FrameType.INTERMEDIATE)
            minOf(d / 2, 8.0 * minOf(inp.topDia, inp.botDia).toDouble(),
                24.0 * inp.stirrupDia, 300.0)
        else d / 2

        val zoneLenMm = if (inp.frameType == FrameType.INTERMEDIATE) (2 * inp.h).toInt() else 0

        val sCrit = max(50, (floor(minOf(sDemand, sMaxCrit) / 25) * 25).toInt())
        val sMid  = max(50, (floor(minOf(sDemand, d / 2, 300.0) / 25) * 25).toInt())

        val avSProvided = (avTotal / sCrit) * 1000.0

        // ── Stirrup weight ──────────────────────────────────────────────────
        val perim = 2.0 * ((inp.b - 80) + (inp.h - 80)) / 1000.0  // m
        val hookLen = 2.0 * stirrupHookExt / 1000.0
        val stirrupWeight = (inp.stirrupDia.toDouble().pow(2) / 162.0) * (perim + hookLen) * (1000.0 / sCrit)

        // ── Stirrup detail notes ────────────────────────────────────────────
        notes += "── STIRRUP DETAILS (ACI 318) ──"
        notes += "Config: 2 Legs Φ${inp.stirrupDia}"
        notes += "Required Av/s:  ${avSReq.fmt2} mm²/m"
        notes += "Provided Av/s:  ${avSProvided.fmt2} mm²/m"
        notes += "Spacing (Critical Zone): ${sCrit} mm c/c"
        if (zoneLenMm > 0) notes += "Spacing (Mid-Span): ${sMid} mm c/c"
        notes += "Stirrup Hook Ext (135°): ${stirrupHookExt.toInt()} mm"
        notes += "Approx Stirrup Weight: ${stirrupWeight.fmt2} kg/m"

        if (inp.leftSupport == SupportType.EXTERNAL || inp.rightSupport == SupportType.EXTERNAL) {
            notes += "── HOOK DEVELOPMENT (ACI 18.8.5) ──"
            notes += "Top Ldh: ${ldHTop.toInt()} mm  |  Extension: ${hookExtTop.toInt()} mm"
            notes += "Bot Ldh: ${ldHBot.toInt()} mm  |  Extension: ${hookExtBot.toInt()} mm"
        }

        val nTop = calculateBars(inp.asTop, inp.topDia)
        val nBot = calculateBars(inp.asBot, inp.botDia)

        return BeamResult(
            nTop = nTop, nBot = nBot,
            asMinReq = asMin, phiVc = phiVc,
            avSReq = avSReq, avSProvided = avSProvided,
            sCrit = sCrit, sMid = sMid, zoneLenMm = zoneLenMm,
            ldHTop = ldHTop, ldHBot = ldHBot,
            hookExtTop = hookExtTop, hookExtBot = hookExtBot,
            stirrupHookExt = stirrupHookExt,
            stirrupWeightPerMeter = stirrupWeight,
            notes = notes, warnings = warnings,
            input = inp
        )
    }

    // ── Extension helpers ───────────────────────────────────────────────────
    private val Double.fmt1 get() = "%.1f".format(this)
    private val Double.fmt2 get() = "%.2f".format(this)
}
