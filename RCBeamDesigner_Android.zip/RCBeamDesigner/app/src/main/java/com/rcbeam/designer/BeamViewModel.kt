package com.rcbeam.designer

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class BeamViewModel : ViewModel() {
    val result = MutableLiveData<BeamResult?>()
    val lastInput = MutableLiveData<BeamInput?>()
}
