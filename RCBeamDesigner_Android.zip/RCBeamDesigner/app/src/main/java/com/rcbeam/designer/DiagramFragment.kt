package com.rcbeam.designer

import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.view.*
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import kotlin.math.min

class DiagramFragment : Fragment() {

    private val vm: BeamViewModel by activityViewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_diagram, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val beamView = view.findViewById<BeamDrawingView>(R.id.beamDrawingView)
        val tvEmpty  = view.findViewById<TextView>(R.id.tvDiagramEmpty)

        vm.result.observe(viewLifecycleOwner) { result ->
            if (result == null) {
                tvEmpty.visibility = View.VISIBLE
                beamView.visibility = View.GONE
            } else {
                tvEmpty.visibility = View.GONE
                beamView.visibility = View.VISIBLE
                beamView.setResult(result)
            }
        }
    }
}

// ─── Custom Drawing View ──────────────────────────────────────────────────────
class BeamDrawingView(context: Context, attrs: android.util.AttributeSet? = null) :
    View(context, attrs) {

    private var result: BeamResult? = null

    fun setResult(r: BeamResult) { result = r; invalidate() }

    // ── Paints ─────────────────────────────────────────────────────────────
    private val paintBeam   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FAFAFA"); style = Paint.Style.FILL }
    private val paintBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#212121"); style = Paint.Style.STROKE; strokeWidth = 3f }
    private val paintStirup = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#D32F2F"); style = Paint.Style.STROKE; strokeWidth = 2f }
    private val paintBarTop = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0D47A1"); style = Paint.Style.FILL }
    private val paintBarBot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1565C0"); style = Paint.Style.FILL }
    private val paintLabel  = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#212121"); textSize = 28f; textAlign = Paint.Align.CENTER }
    private val paintRed    = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#C62828"); textSize = 24f; textAlign = Paint.Align.CENTER }
    private val paintBlue   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0D47A1"); textSize = 24f; textAlign = Paint.Align.CENTER }
    private val paintPurple = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#6A1B9A"); style = Paint.Style.STROKE; strokeWidth = 1.5f }
    private val paintGrey   = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#757575"); style = Paint.Style.STROKE; strokeWidth = 1f }
    private val paintDim    = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#555555"); textSize = 22f; textAlign = Paint.Align.CENTER }
    private val paintColumn = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E0E0E0"); style = Paint.Style.FILL_AND_STROKE; strokeWidth = 1.5f }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val r = result ?: return

        canvas.drawColor(Color.parseColor("#F5F5F5"))

        val w = width.toFloat()
        val h = height.toFloat()
        val half = h / 2f

        drawCrossSection(canvas, r, 0f, 0f, w * 0.35f, half)
        drawElevation(canvas, r, 0f, half, w, half)
    }

    // ── Cross-section ──────────────────────────────────────────────────────
    private fun drawCrossSection(canvas: Canvas, r: BeamResult, ox: Float, oy: Float, panelW: Float, panelH: Float) {
        val inp = r.input
        val scale = min((panelW - 80) / inp.b, (panelH - 100) / inp.h).toFloat()
        val bPx = (inp.b * scale)
        val hPx = (inp.h * scale)
        val cx = ox + panelW / 2f
        val cy = oy + panelH / 2f
        val left = cx - bPx / 2; val top = cy - hPx / 2
        val cover = 40 * scale

        // Section body
        canvas.drawRect(left, top, left + bPx, top + hPx, paintBeam)
        canvas.drawRect(left, top, left + bPx, top + hPx, paintBorder)

        // Stirrup rectangle
        canvas.drawRect(left + cover, top + cover, left + bPx - cover, top + hPx - cover, paintStirup)

        // Title
        paintLabel.textSize = 26f
        canvas.drawText("Cross Section  ${inp.b.toInt()}×${inp.h.toInt()} mm", cx, oy + 28f, paintLabel)

        // Top bars
        val barRTop = (inp.topDia * scale / 1.8f).coerceAtLeast(8f)
        val topY = top + cover + barRTop
        val topXs = barPositions(cx, bPx, cover, r.nTop)
        topXs.forEach { canvas.drawCircle(it, topY, barRTop, paintBarTop) }

        // Bot bars
        val barRBot = (inp.botDia * scale / 1.8f).coerceAtLeast(7f)
        val botY = top + hPx - cover - barRBot
        val botXs = barPositions(cx, bPx, cover, r.nBot)
        botXs.forEach { canvas.drawCircle(it, botY, barRBot, paintBarBot) }

        // Labels
        paintRed.textSize = 26f
        canvas.drawText("${r.nTop} Φ${inp.topDia}", cx, topY + barRTop + 30f, paintRed)
        paintBlue.textSize = 26f
        canvas.drawText("${r.nBot} Φ${inp.botDia}", cx, botY - barRBot - 10f, paintBlue)

        // Stirrup label
        paintDim.textSize = 22f
        canvas.drawText("Stirrups Φ${inp.stirrupDia} @ ${r.sCrit}mm", cx, oy + panelH - 10f, paintDim)
    }

    private fun barPositions(cx: Float, bPx: Float, cover: Float, n: Int): List<Float> {
        if (n == 1) return listOf(cx)
        val usable = bPx - 2 * cover
        return (0 until n).map { cx - bPx / 2 + cover + it * usable / (n - 1) }
    }

    // ── Elevation ──────────────────────────────────────────────────────────
    private fun drawElevation(canvas: Canvas, r: BeamResult, ox: Float, oy: Float, panelW: Float, panelH: Float) {
        val inp = r.input
        val L = 5000            // representative span mm
        val beamHmm = inp.h
        val scale = min((panelW - 160) / (L + 300f), (panelH - 100) / (beamHmm + 200f)).toFloat()
        val lPx = L * scale
        val bHpx = beamHmm * scale
        val colW = 80 * scale
        val startX = ox + (panelW - lPx) / 2f
        val topBeam = oy + (panelH - bHpx) / 2f

        paintLabel.textSize = 26f
        canvas.drawText("Longitudinal & Shear Layout", ox + panelW / 2, oy + 28f, paintLabel)

        // Columns
        listOf(startX - colW, startX + lPx).forEachIndexed { i, x ->
            canvas.drawRect(x, topBeam - 20, x + colW, topBeam + bHpx + 20, paintColumn)
            paintDim.textSize = 18f
            val label = if (i == 0) inp.leftSupport.label else inp.rightSupport.label
            canvas.save(); canvas.rotate(-90f, x + colW / 2, topBeam + bHpx / 2)
            canvas.drawText(label, x + colW / 2, topBeam + bHpx / 2 + 6, paintDim); canvas.restore()
        }

        // Beam body
        canvas.drawRect(startX, topBeam, startX + lPx, topBeam + bHpx, paintBeam)
        canvas.drawRect(startX, topBeam, startX + lPx, topBeam + bHpx, paintBorder)

        // Top & bot rebar lines
        val coverPx = 30 * scale
        canvas.drawLine(startX, topBeam + coverPx, startX + lPx, topBeam + coverPx, Paint(paintStirup).apply { strokeWidth = 4f; color = Color.parseColor("#C62828") })
        canvas.drawLine(startX, topBeam + bHpx - coverPx, startX + lPx, topBeam + bHpx - coverPx, Paint(paintStirup).apply { strokeWidth = 4f; color = Color.parseColor("#0D47A1") })

        // Stirrups – critical zone
        val zonePx = r.zoneLenMm * scale
        val sCritPx = r.sCrit * scale
        var x = startX + sCritPx
        while (x < startX + zonePx && x < startX + lPx - sCritPx) {
            canvas.drawLine(x, topBeam + coverPx, x, topBeam + bHpx - coverPx, paintPurple)
            x += sCritPx
        }

        // Stirrups – mid zone
        val sMidPx = r.sMid * scale
        x = startX + zonePx + sMidPx
        while (x < startX + lPx - zonePx) {
            canvas.drawLine(x, topBeam + coverPx, x, topBeam + bHpx - coverPx, paintGrey)
            x += sMidPx
        }

        // Symmetric right critical zone
        x = startX + lPx - zonePx
        while (x < startX + lPx) {
            canvas.drawLine(x, topBeam + coverPx, x, topBeam + bHpx - coverPx, paintPurple)
            x += sCritPx
        }

        // Dimension annotations
        paintDim.textSize = 20f
        if (r.zoneLenMm > 0) {
            // crit zone arrow
            val arrowY = topBeam + bHpx + 30f
            canvas.drawLine(startX, arrowY, startX + zonePx, arrowY, paintPurple)
            canvas.drawText("${r.zoneLenMm}mm @ ${r.sCrit}mm c/c", startX + zonePx / 2, arrowY + 25f, Paint(paintDim).apply { color = Color.parseColor("#6A1B9A"); textAlign = Paint.Align.CENTER; textSize = 20f })

            // mid zone
            val midStart = startX + zonePx
            val midEnd = startX + lPx - zonePx
            if (midEnd > midStart) {
                canvas.drawLine(midStart, arrowY, midEnd, arrowY, paintGrey)
                canvas.drawText("Mid @ ${r.sMid}mm c/c", (midStart + midEnd) / 2, arrowY + 25f, Paint(paintDim).apply { color = Color.parseColor("#616161"); textAlign = Paint.Align.CENTER; textSize = 20f })
            }
        }
    }
}
