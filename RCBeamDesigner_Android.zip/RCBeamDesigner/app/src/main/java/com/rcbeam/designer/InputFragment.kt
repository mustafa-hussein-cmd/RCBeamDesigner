package com.rcbeam.designer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText

class InputFragment : Fragment() {

    private val vm: BeamViewModel by activityViewModels()

    // ── Views (lateinit) ──────────────────────────────────────────────────
    private lateinit var spFrameType: Spinner
    private lateinit var spLeftSupport: Spinner
    private lateinit var spRightSupport: Spinner
    private lateinit var etB: TextInputEditText
    private lateinit var etH: TextInputEditText
    private lateinit var etAsTop: TextInputEditText
    private lateinit var etAsBot: TextInputEditText
    private lateinit var spTopDia: Spinner
    private lateinit var spBotDia: Spinner
    private lateinit var spStirrupDia: Spinner
    private lateinit var spShearMethod: Spinner
    private lateinit var etShearValue: TextInputEditText
    private lateinit var btnRun: MaterialButton

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_input, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bindViews(view)
        setupSpinners()
        restoreValues()

        btnRun.setOnClickListener { runDesign(view) }
    }

    private fun bindViews(v: View) {
        spFrameType    = v.findViewById(R.id.spFrameType)
        spLeftSupport  = v.findViewById(R.id.spLeftSupport)
        spRightSupport = v.findViewById(R.id.spRightSupport)
        etB            = v.findViewById(R.id.etB)
        etH            = v.findViewById(R.id.etH)
        etAsTop        = v.findViewById(R.id.etAsTop)
        etAsBot        = v.findViewById(R.id.etAsBot)
        spTopDia       = v.findViewById(R.id.spTopDia)
        spBotDia       = v.findViewById(R.id.spBotDia)
        spStirrupDia   = v.findViewById(R.id.spStirrupDia)
        spShearMethod  = v.findViewById(R.id.spShearMethod)
        etShearValue   = v.findViewById(R.id.etShearValue)
        btnRun         = v.findViewById(R.id.btnRun)
    }

    private fun setupSpinners() {
        val ctx = requireContext()
        val diameters = listOf("10", "12", "16", "20", "25", "32")

        spFrameType.adapter    = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item,
            FrameType.values().map { it.label })
        spLeftSupport.adapter  = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item,
            SupportType.values().map { it.label })
        spRightSupport.adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item,
            SupportType.values().map { it.label })
        spTopDia.adapter       = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, diameters)
        spBotDia.adapter       = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, diameters)
        spStirrupDia.adapter   = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, diameters)
        spShearMethod.adapter  = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item,
            ShearMethod.values().map { it.label })

        // defaults matching the Python app
        spFrameType.setSelection(1)       // Intermediate
        spLeftSupport.setSelection(0)     // External
        spRightSupport.setSelection(1)    // Internal
        spTopDia.setSelection(3)          // Φ20
        spBotDia.setSelection(2)          // Φ16
        spStirrupDia.setSelection(0)      // Φ10
        spShearMethod.setSelection(0)     // Vu
    }

    private fun restoreValues() {
        vm.lastInput.value?.let { inp ->
            etB.setText(inp.b.toInt().toString())
            etH.setText(inp.h.toInt().toString())
            etAsTop.setText(inp.asTop.toInt().toString())
            etAsBot.setText(inp.asBot.toInt().toString())
            etShearValue.setText(inp.shearValue.toString())
        }
    }

    private fun runDesign(root: View) {
        try {
            val inp = BeamInput(
                b            = etB.text.toString().toDoubleOrNull() ?: 300.0,
                h            = etH.text.toString().toDoubleOrNull() ?: 600.0,
                asTop        = etAsTop.text.toString().toDoubleOrNull() ?: 0.0,
                asBot        = etAsBot.text.toString().toDoubleOrNull() ?: 0.0,
                topDia       = spTopDia.selectedItem.toString().toInt(),
                botDia       = spBotDia.selectedItem.toString().toInt(),
                stirrupDia   = spStirrupDia.selectedItem.toString().toInt(),
                shearValue   = etShearValue.text.toString().toDoubleOrNull() ?: 0.0,
                inputMethod  = ShearMethod.fromLabel(spShearMethod.selectedItem.toString()),
                frameType    = FrameType.fromLabel(spFrameType.selectedItem.toString()),
                leftSupport  = SupportType.fromLabel(spLeftSupport.selectedItem.toString()),
                rightSupport = SupportType.fromLabel(spRightSupport.selectedItem.toString())
            )

            val result = BeamDesignEngine.design(inp)
            vm.result.value = result
            vm.lastInput.value = inp

            // Navigate to results tab
            activity?.findViewById<BottomNavigationView>(R.id.bottom_navigation)
                ?.selectedItemId = R.id.nav_results

        } catch (ex: Exception) {
            Snackbar.make(root, "Error: ${ex.message}", Snackbar.LENGTH_LONG).show()
        }
    }
}
