package com.rcbeam.designer

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.google.android.material.card.MaterialCardView

class ResultsFragment : Fragment() {

    private val vm: BeamViewModel by activityViewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_results, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val container = view.findViewById<LinearLayout>(R.id.resultsContainer)
        val tvEmpty   = view.findViewById<TextView>(R.id.tvEmpty)

        vm.result.observe(viewLifecycleOwner) { result ->
            container.removeAllViews()

            if (result == null) {
                tvEmpty.visibility = View.VISIBLE
                return@observe
            }
            tvEmpty.visibility = View.GONE

            // ── Summary card ─────────────────────────────────────────────
            addCard(container, buildSummary(result), isWarning = false, isHeader = true)

            // ── Warnings ─────────────────────────────────────────────────
            if (result.warnings.isNotEmpty()) {
                result.warnings.forEach { w ->
                    addCard(container, w, isWarning = true)
                }
            } else {
                addCard(container, "✅ All ACI 318 checks PASSED", isWarning = false, isSuccess = true)
            }

            // ── Detail notes ──────────────────────────────────────────────
            result.notes.forEach { note ->
                addCard(container, note, isWarning = false)
            }
        }
    }

    private fun buildSummary(r: BeamResult): String {
        val inp = r.input
        return """
📐 DESIGN SUMMARY
━━━━━━━━━━━━━━━━━━━━
Section:  ${inp.b.toInt()} × ${inp.h.toInt()} mm
Frame:    ${inp.frameType.label}

Top Steel:  ${r.nTop} Φ${inp.topDia}   (As = ${"%.0f".format(r.nTop * (BeamConstants.BAR_DIAMETERS[inp.topDia] ?: 0.0))} mm²)
Bot Steel:  ${r.nBot} Φ${inp.botDia}   (As = ${"%.0f".format(r.nBot * (BeamConstants.BAR_DIAMETERS[inp.botDia] ?: 0.0))} mm²)

Stirrups:   Φ${inp.stirrupDia} @ ${r.sCrit} mm (crit)
             Φ${inp.stirrupDia} @ ${r.sMid} mm (mid)

φVc = ${"%.1f".format(r.phiVc)} kN
        """.trimIndent()
    }

    private fun addCard(
        parent: LinearLayout,
        text: String,
        isWarning: Boolean,
        isSuccess: Boolean = false,
        isHeader: Boolean = false
    ) {
        val ctx = requireContext()

        val card = MaterialCardView(ctx).apply {
            radius = 12f
            cardElevation = if (isHeader) 6f else 2f
            val margin = (8 * resources.displayMetrics.density).toInt()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(margin, margin / 2, margin, margin / 2) }

            setCardBackgroundColor(when {
                isWarning -> Color.parseColor("#FFF3E0")
                isSuccess -> Color.parseColor("#E8F5E9")
                isHeader  -> Color.parseColor("#E3F2FD")
                else      -> Color.parseColor("#FAFAFA")
            })

            strokeWidth = if (isWarning || isSuccess) 2 else 0
            strokeColor = when {
                isWarning -> Color.parseColor("#FF6D00")
                isSuccess -> Color.parseColor("#2E7D32")
                else      -> Color.TRANSPARENT
            }
        }

        val tv = TextView(ctx).apply {
            this.text = text
            textSize = if (isHeader) 14f else 13f
            setTextColor(when {
                isWarning -> Color.parseColor("#BF360C")
                isSuccess -> Color.parseColor("#1B5E20")
                isHeader  -> Color.parseColor("#0D47A1")
                else      -> Color.parseColor("#212121")
            })
            val pad = (12 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
            fontFeatureSettings = "\"tnum\""
            typeface = if (isHeader) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.MONOSPACE
        }

        card.addView(tv)
        parent.addView(card)
    }
}
